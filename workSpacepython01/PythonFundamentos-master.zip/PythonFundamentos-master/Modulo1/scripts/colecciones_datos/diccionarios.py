

# A diferencia de las listas, en los diccionarios no tengo existe un indice


lista_nums = [15, 75]

dicx = {
    'numero1': 15,
    'numero2': 75
}

lista_nums[0]

dicx['numero1']

dicx['numero2']

