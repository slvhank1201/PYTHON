


# imaginate que te piden guardar 20 variables 

# a = ''
# b = ''
# c = ''
# num1 = ''
# num2=''


# lista - > nos permite almacenar un conjunto de valores
lista_vacia = list() # []  -> lista vacia o lista sin elementos
lista_valores = [1, 2, 'hola', 'x', True, False, 3.14] 


print(f'La lista es: {lista_valores}')
print('Cantidad de elementos en lista: ', len(lista_valores))

# ordenamiento de 0 a n-1
print(f'El elemento que ocupa la posición 4 es: { lista_valores[4]}')
# ordenamiento inverso -1 a -n
print(f'El elemento que ocupa la posición 4 es: { lista_valores[-1]}')



# muchos ide's o editores de codigo tienen autocompletado


lista_valores

















