

semaforo = input('Ingrese el color del semaforo: ')



if semaforo == 'verde':
    print('Cruce la calle')
elif semaforo=='rojo' or semaforo == 'amarillo':
    print('No cruces')
else:
    print('No es un color de semaforo')
     
print('Programa terminado!! ')



