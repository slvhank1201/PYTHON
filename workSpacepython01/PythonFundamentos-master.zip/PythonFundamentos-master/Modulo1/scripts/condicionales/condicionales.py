# CINE 
# Mayores de edad pagan 20$
# menores pagan 10$


edad = int(input('Ingrese su edad: '))

# si la persona es mayor de edad, paga 20$
# sino paga 10$

if edad >= 18: # Si es verdad
    # logica
    print('Es mayor de edad, pague 20$')
    pass # fin if
else: # en otro caso
    print('Es menor de edad, pague 10$')
    pass # fin else 

print('Programa finalizado!')




