

numero = 3


if numero %2 == 0:
    print('Es un numero par')
    
print('Programa Finalizado')

