# control + s -> guardar cambios 

edad1 = int(input('Ingrese la primera edad: '))
edad2 = int(input('Ingrese la segunda edad: '))

# f o format -> me permiten dar formato a texto
print(f'La edad de la persona 1 es {edad1}')
print('La edad de la persona 2 es {}'.format(edad2))

edad_suma = edad1 + edad2
print(f'La suma de las edades es : {edad_suma}')





