# 1.
print('hola')

# 2.
print('solucio 2')