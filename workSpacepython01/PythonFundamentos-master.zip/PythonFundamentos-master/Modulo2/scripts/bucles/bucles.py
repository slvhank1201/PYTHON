
# Imaginate que te piden imprimir la palabra hola 20 veces

# control + alt + fecha(arriba o abajo)
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')
# print('hola')


# Los bucles me van a ayudar a realizar una tarea un número de veces

# for navega a partir de una lista o una coleccion de datos

# range([valor_inicio], valor_fin, [salto])
# for _ in range(100):
#     print('hola')

# imprime los numeros del 1 al 20
for n in range(21):
    print(n)



# Mientras el numero sea menor a 20, escribe "hola n" donde n es el numero en el momento que imprimo
# While -> Realiza una tarea mientras la condición sea verdad

# numero=5
# while (numero <20):
#     print('hola', numero)
#     numero -=1



 









